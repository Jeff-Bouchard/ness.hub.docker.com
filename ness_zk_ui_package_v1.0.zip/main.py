from fastapi import FastAPI, Request, HTTPException
import base64
import tempfile
import subprocess
import os

from fastapi.staticfiles import StaticFiles

app = FastAPI(title="WASM MCP Gateway (wasmtime CLI, ZK demo, NESS-Network/IPVM)")

from fastapi.middleware.cors import CORSMiddleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.mount("/static", StaticFiles(directory="static"), name="static")

@app.post("/run_wasm_job")
async def run_wasm_job(request: Request):
    data = await request.json()
    wasm_b64 = data["wasm_b64"]
    wasm_bytes = base64.b64decode(wasm_b64)
    with tempfile.NamedTemporaryFile(delete=False, suffix='.wasm') as f:
        f.write(wasm_bytes)
        wasm_path = f.name
    try:
        result = subprocess.run([
            "wasmtime", wasm_path
        ], capture_output=True, text=True, timeout=10)
        output = result.stdout.strip()
        error = result.stderr.strip()
        status = result.returncode
    except Exception as e:
        raise HTTPException(status_code=500, detail="WASM execution error.")
    finally:
        os.unlink(wasm_path)
    return {"status": "executed", "output": output, "error": error, "exit_code": status}

# --- ZK Proof Demo Endpoints ---
from zk_demo.prover import schnorr_prove
from zk_demo.verifier import schnorr_verify

@app.post("/zk/prove")
async def zk_prove(request: Request):
    data = await request.json()
    y = int(data["y"])
    x = int(data["x"])
    z = x + y
    proof = schnorr_prove(x, y, z)
    return {"y": y, "z": z, "proof": proof}

import traceback

@app.post("/zk/verify")
async def zk_verify(request: Request):
    try:
        data = await request.json()
        y = int(data["y"])
        z = int(data["z"])
        proof = data["proof"]
        valid = schnorr_verify(y, z, proof)
        return {"valid": valid}
    except Exception as e:
        tb = traceback.format_exc()
        print(f"[zk_verify] Exception: {e}\nTraceback:\n{tb}\nInput: {data}")
        return {"error": str(e), "traceback": tb, "input": data}

@app.get("/")
def root():
    return {"status": "MCP Gateway running", "zk_demo": ["/zk/prove", "/zk/verify"], "wasm_job": "/run_wasm_job"}

