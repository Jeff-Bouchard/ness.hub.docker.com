#!/usr/bin/env bash
set -euo pipefail

# NESS/IPVM - Runner for zk_ui.html demo
# Starts uvicorn on 127.0.0.1:8011 and opens the UI page.

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"

PORT=8011

if [ ! -d ".venv" ]; then
  echo "Missing .venv. Run ./install_zk_ui.sh first." >&2
  exit 1
fi
# shellcheck disable=SC1091
source .venv/bin/activate

# Validate required Python packages
python - <<'PY'
import importlib, sys
for pkg in ("fastapi", "uvicorn"):
    try:
        importlib.import_module(pkg)
    except Exception as e:
        print(f"[ERR] Missing Python package: {pkg}. Run ./install_zk_ui.sh", file=sys.stderr)
        sys.exit(1)
print("ok")
PY

# Start server
echo "Starting FastAPI server on http://127.0.0.1:${PORT}"
( uvicorn main:app --port ${PORT} --workers 1 & echo $! > .uvicorn.pid )

# Wait briefly for server
sleep 1

URL="http://127.0.0.1:${PORT}/static/zk_ui.html"
echo "Opening UI: ${URL}"
# Try common openers; ignore errors
if command -v xdg-open >/dev/null 2>&1; then
  xdg-open "$URL" >/dev/null 2>&1 || true
elif command -v sensible-browser >/dev/null 2>&1; then
  sensible-browser "$URL" >/dev/null 2>&1 || true
elif command -v gnome-open >/dev/null 2>&1; then
  gnome-open "$URL" >/dev/null 2>&1 || true
fi

echo "Press Ctrl+C to stop. To stop background server manually: kill \"$(cat .uvicorn.pid 2>/dev/null || echo <none>)\""
wait
