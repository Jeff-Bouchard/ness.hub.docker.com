#!/usr/bin/env bash
set -euo pipefail

# NESS/IPVM - Installer for zk_ui.html demo
# - Creates Python venv in .venv/
# - Installs Python deps from requirements.txt
# - Verifies wasmtime is available (optional auto-install with --auto-wasmtime)
# - Prints next steps to launch the UI

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"

AUTO_WASMTIME=0
for arg in "$@"; do
  case "$arg" in
    --auto-wasmtime)
      AUTO_WASMTIME=1
      shift
      ;;
    *) ;;
  esac
done

bold() { printf "\033[1m%s\033[0m\n" "$*"; }
info() { printf "[INFO] %s\n" "$*"; }
warn() { printf "[WARN] %s\n" "$*"; }
err()  { printf "[ERR ] %s\n" "$*"; }

bold "NESS/IPVM ZK UI Installer"

# 1) Check Python
if ! command -v python3 >/dev/null 2>&1; then
  err "python3 not found. Please install Python 3.10+ and re-run."
  exit 1
fi

PY_VER="$(python3 -c 'import sys; print("%d.%d"%sys.version_info[:2])')" || true
info "Detected Python ${PY_VER}"

# 2) Create venv if missing
if [ ! -d ".venv" ]; then
  info "Creating virtual environment at .venv/"
  python3 -m venv .venv
fi
# shellcheck disable=SC1091
source .venv/bin/activate

# 3) Upgrade pip tooling
info "Upgrading pip/setuptools/wheel"
pip install --upgrade pip setuptools wheel

# 4) Install Python requirements
if [ -f requirements.txt ]; then
  info "Installing Python dependencies from requirements.txt"
  # --ignore-requires-python helps when running on latest Python versions
  pip install --ignore-requires-python --no-build-isolation --no-cache-dir -r requirements.txt
else
  warn "requirements.txt not found; installing minimal deps"
  pip install --ignore-requires-python --no-build-isolation --no-cache-dir fastapi uvicorn pycryptodome
fi

# 5) Verify wasmtime availability (required for /run_wasm_job)
if command -v wasmtime >/dev/null 2>&1; then
  info "wasmtime found: $(command -v wasmtime)"
else
  warn "wasmtime is not installed. It's required for running uploaded WASM jobs."
  if [ "$AUTO_WASMTIME" -eq 1 ]; then
    info "Attempting to install wasmtime automatically..."
    if command -v apt-get >/dev/null 2>&1; then
      sudo apt-get update && sudo apt-get install -y wasmtime || true
    elif command -v dnf >/dev/null 2>&1; then
      sudo dnf install -y wasmtime || true
    elif command -v pacman >/dev/null 2>&1; then
      sudo pacman -Sy --noconfirm wasmtime || true
    elif command -v brew >/dev/null 2>&1; then
      brew install wasmtime || true
    else
      warn "Falling back to upstream install script (wasmtime.dev)."
      curl https://wasmtime.dev/install.sh -sSf | bash || true
      if [ -d "$HOME/.wasmtime/bin" ]; then
        export PATH="$HOME/.wasmtime/bin:$PATH"
      fi
    fi

    if command -v wasmtime >/dev/null 2>&1; then
      info "wasmtime installed successfully."
    else
      warn "wasmtime installation attempt failed. Please install it manually: https://wasmtime.dev/"
    fi
  else
    warn "Skip auto-install. You can re-run with --auto-wasmtime to attempt install."
  fi
fi

bold "Install complete."
cat <<'EOS'

Next steps:
1) Start the API and open the UI:
   ./start_zk_ui.sh

   This will:
   - run FastAPI (uvicorn) on http://127.0.0.1:8011
   - open your browser at /static/zk_ui.html

2) If you prefer manual start:
   source .venv/bin/activate
   uvicorn main:app --port 8011 --workers 1
   # then open http://127.0.0.1:8011/static/zk_ui.html in your browser

Notes:
- The UI expects endpoints at 127.0.0.1:8011 (see static/zk_ui.html).
- The WASM job runner requires the `wasmtime` CLI to be installed.
EOS
