# Verifier for Schnorr-like ZK proof for x + y = z
from hashlib import sha256

def schnorr_verify(y, z, proof):
    t = proof["t"]
    s_raw = proof["s"]
    try:
        s = int(s_raw)
    except ValueError:
        s = int(float(s_raw))
    # Recompute challenge
    c = int(sha256(f'{t}{y}{z}'.encode()).hexdigest(), 16)
    # Check (simulate commitment)
    # In real Schnorr, we'd check g^s = t * (g^x)^c, but here we use hashes for demo
    t_prime = sha256(str(s - c * (z - y)).encode()).hexdigest()
    return t == t_prime
