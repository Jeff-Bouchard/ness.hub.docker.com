# Simple Schnorr-like ZK proof for x + y = z
# Prover proves knowledge of x such that x + y = z, without revealing x
from Crypto.Random import random
from hashlib import sha256
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

app = FastAPI()

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # Or ["http://127.0.0.1:8011"] to restrict
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

def schnorr_prove(x, y, z):
    # Commitment
    r = random.randint(1, 2**128)
    t = sha256(str(r).encode()).hexdigest()
    # Challenge (Fiat-Shamir heuristic)
    c = int(sha256(f'{t}{y}{z}'.encode()).hexdigest(), 16)
    # Response
    s = r + c * x
    return {"t": t, "s": str(s)}
