#!/usr/bin/env bash
set -euo pipefail

# Simple test script for the NESS/IPVM ZK UI backend.
# Requires the server to be running on http://127.0.0.1:8011

BASE="http://127.0.0.1:8011"

bold() { printf "\033[1m%s\033[0m\n" "$*"; }

bold "GET /"
curl -sS "$BASE/" | jq . || curl -sS "$BASE/"

echo
bold "POST /zk/prove"
curl -sS -X POST "$BASE/zk/prove" \
  -H 'Content-Type: application/json' \
  -d '{"formula":"x + y = z","x":5,"y":7}' | jq . || true

echo
bold "POST /zk/verify (using t,s from previous output if you paste manually)"
# Example body structure; fill t/s from /zk/prove result
cat <<'JSON'
{
  "formula": "x + y = z",
  "y": 7,
  "z": 12,
  "proof": { "t": "<paste>", "s": "<paste>" }
}
JSON
# Example curl (edit t/s):
# curl -sS -X POST "$BASE/zk/verify" -H 'Content-Type: application/json' -d '{"formula":"x + y = z","y":7,"z":12,"proof":{"t":"...","s":"..."}}' | jq .

echo
bold "POST /run_wasm_job (using addwasm.wasm)"
if command -v base64 >/dev/null 2>&1; then
  WASM_B64=$(base64 -w0 addwasm.wasm)
  curl -sS -X POST "$BASE/run_wasm_job" \
    -H 'Content-Type: application/json' \
    -d "{\"wasm_b64\":\"$WASM_B64\"}" | jq . || true
else
  echo "base64 utility not found; skipping WASM test."
fi
