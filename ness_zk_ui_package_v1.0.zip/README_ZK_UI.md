# NESS/IPVM ZK UI Package

This package contains a minimal setup to run the NESS ZK Proof Playground UI and its FastAPI backend.

## Contents
- `static/zk_ui.html` — Web UI
- `main.py` — FastAPI backend (ZK demo + WASM runner)
- `requirements.txt` — Python dependencies
- `install_zk_ui.sh` — Installer (creates venv, installs deps, checks `wasmtime`)
- `start_zk_ui.sh` — Starts server on `http://127.0.0.1:8011` and opens the UI
- `zk_demo/` — ZK prover and verifier module

## Prerequisites
- Linux with Python 3.10+
- Optional: `wasmtime` CLI (required for `/run_wasm_job`). You can auto-install with the installer flag below.

## Quick Start
```bash
# 1) Install
./install_zk_ui.sh               # or: ./install_zk_ui.sh --auto-wasmtime

# 2) Run
./start_zk_ui.sh
# Browser should open automatically. If not, visit:
# http://127.0.0.1:8011/static/zk_ui.html
```

## Manual Start (alternative)
```bash
source .venv/bin/activate
uvicorn main:app --port 8011 --workers 1
# Then open http://127.0.0.1:8011/static/zk_ui.html
```

## Notes
- The UI references endpoints at `http://127.0.0.1:8011` (see `static/zk_ui.html`).
- WASM job execution relies on `wasmtime`. Install via your package manager or `https://wasmtime.dev/` if not using `--auto-wasmtime`.
